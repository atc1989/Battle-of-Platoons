import { supabase } from "./supabase";

/**
 * Fetch + aggregate leaderboard rows from Supabase.
 *
 * Assumes:
 * - raw_data has: leads, payins, sales, agent_id (or agentId), date_real (preferred) OR date (jsonb timestamp)
 * - agents has: id, name, photoURL, platoonId (or platoon), depotId (or depot), companyId (or company)
 * - depots/companies/platoons tables exist for optional logos/names
 */
export async function getLeaderboard({
  startDate, // "YYYY-MM-DD"
  endDate,   // "YYYY-MM-DD"
  groupBy = "leaders", // "leaders" | "depots" | "companies"
  scoring = defaultScore,
}) {
  // 1) Pull raw rows + joined agent (left join style via select)
  // NOTE: We filter by date_real if it exists; if you have not backfilled date_real yet,
  // the fallback filter runs in JS using `date` jsonb timestamps.
  const { data: rawRows, error } = await supabase
    .from("raw_data")
    .select(
      `
      id,
      leads,
      payins,
      sales,
      date_real,
      date,
      agent_id,
      agentId,
      agents:agents (
        id,
        name,
        photoURL,
        platoonId,
        platoon,
        depotId,
        depot,
        companyId,
        company
      )
    `
    );

  if (error) throw error;

  // 2) Filter to date window
  const start = new Date(`${startDate}T00:00:00`);
  const end = new Date(`${endDate}T23:59:59`);

  const filtered = (rawRows ?? []).filter((r) => {
    const d = getRowDate(r);
    if (!d) return false;
    return d >= start && d <= end;
  });

  // 3) Aggregate
  const aggregated = aggregateLeaderboard(filtered, groupBy, scoring);

  // 4) For depots/companies: fetch logos + pretty names (optional)
  // This lets podium/table show avatars for depots/companies too.
  if (groupBy === "depots") {
    await attachLookupMeta(aggregated, "depots");
  } else if (groupBy === "companies") {
    await attachLookupMeta(aggregated, "companies");
  }

  return aggregated;
}

/* ------------------------------ Aggregation ------------------------------ */

function aggregateLeaderboard(rows, mode, scoringFn) {
  const map = new Map();

  for (const r of rows) {
    const a = r.agents || {};
    const leads = toNumber(r.leads);
    const payins = toNumber(r.payins);
    const sales = toNumber(r.sales);

    const agentId = (r.agent_id ?? r.agentId ?? a.id ?? "").toString();

    // Decide grouping key + label + avatar
    let key = "";
    let name = "";
    let avatarUrl = "";

    if (mode === "leaders") {
      key = agentId;
      name = a.name ?? "(Unnamed)";
      avatarUrl = a.photoURL ?? "";
    } else if (mode === "depots") {
      key = (a.depotId ?? a.depot ?? "").toString();
      name = key || "(No Depot)";
    } else if (mode === "companies") {
      key = (a.companyId ?? a.company ?? "").toString();
      name = key || "(No Company)";
    } else {
      key = agentId;
      name = a.name ?? "(Unnamed)";
      avatarUrl = a.photoURL ?? "";
    }

    if (!map.has(key)) {
      map.set(key, {
        key,
        name,
        avatarUrl,
        platoon: mode === "leaders" ? (a.platoonId ?? a.platoon ?? "") : "",
        leads: 0,
        payins: 0,
        sales: 0,
        points: 0,
        rank: 0,
      });
    }

    const item = map.get(key);
    item.leads += leads;
    item.payins += payins;
    item.sales += sales;
  }

  const result = Array.from(map.values()).map((x) => ({
    ...x,
    points: scoringFn(x),
  }));

  result.sort((a, b) => b.points - a.points || b.sales - a.sales || b.leads - a.leads);

  // assign ranks
  for (let i = 0; i < result.length; i++) result[i].rank = i + 1;

  return result;
}

/* ------------------------------ Lookups ------------------------------ */

async function attachLookupMeta(rows, tableName) {
  const keys = Array.from(new Set(rows.map((r) => r.key).filter(Boolean)));
  if (!keys.length) return;

  // Supabase "in" limit is typically fine for small sets; your depots/companies are small.
  const { data, error } = await supabase
    .from(tableName)
    .select("id, name, photoURL, photo_url")
    .in("id", keys);

  if (error) return; // non-fatal

  const byId = new Map((data ?? []).map((d) => [d.id, d]));
  for (const r of rows) {
    const meta = byId.get(r.key);
    if (!meta) continue;
    r.name = meta.name ?? r.name;
    r.avatarUrl = meta.photoURL ?? meta.photo_url ?? r.avatarUrl;
  }
}

/* ------------------------------ Helpers ------------------------------ */

function defaultScore(row) {
  // Replace later with your real scoring formula if needed.
  // Simple baseline:
  // - leads weight 1
  // - payins weight 2
  // - sales weight 0.001 (so 30,000 → 30 pts)
  return toNumber(row.leads) * 1 + toNumber(row.payins) * 2 + toNumber(row.sales) / 1000;
}

function toNumber(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

/**
 * Prefer date_real (date) if present.
 * Fallback to Firestore-exported timestamp JSON in `date`:
 * - { _seconds: 123, _nanoseconds: 0 }
 */
function getRowDate(r) {
  if (r?.date_real) {
    // Supabase returns date as string "YYYY-MM-DD"
    return new Date(`${r.date_real}T00:00:00`);
  }

  const ts = r?.date;
  const d = parseFirestoreTimestampJson(ts);
  return d;
}

function parseFirestoreTimestampJson(ts) {
  if (!ts) return null;

  // Sometimes it’s already a string
  if (typeof ts === "string") {
    const d = new Date(ts);
    return isNaN(d.getTime()) ? null : d;
  }

  // Firestore export style: { _seconds, _nanoseconds }
  const sec = ts._seconds ?? ts.seconds;
  const nsec = ts._nanoseconds ?? ts.nanoseconds ?? 0;

  if (typeof sec === "number") {
    const ms = sec * 1000 + Math.floor(nsec / 1e6);
    const d = new Date(ms);
    return isNaN(d.getTime()) ? null : d;
  }

  return null;
}
