import React from "react";

export default function Updates() {
  return (
    <div className="card">
      <div className="card-title">Updates</div>
      <div className="muted">
        Coming soon — we’ll wire the sliders + divisor exactly like the prototype.
      </div>
    </div>
  );
}
