import React from "react";

export default function Upload() {
  return (
    <div className="card">
      <div className="card-title">Upload</div>
      <div className="muted">
        Coming soon — we’ll wire the sliders + divisor exactly like the prototype.
      </div>
    </div>
  );
}
