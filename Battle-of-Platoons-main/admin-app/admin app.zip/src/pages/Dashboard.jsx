import React from "react";

export default function Dashboard() {
  return (
    <div className="card">
      <div className="card-title">Dashboard</div>
      <div className="muted">
        Next: KPIs + toggle (Leaders/Companies/Depots) + preview podium/table using leaderboard.service.js.
      </div>
    </div>
  );
}
