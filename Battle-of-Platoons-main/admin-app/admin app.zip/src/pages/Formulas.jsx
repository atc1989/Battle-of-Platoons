import React from "react";

export default function Formulas() {
  return (
    <div className="card">
      <div className="card-title">Scoring Formulas</div>
      <div className="muted">
        Coming soon — we’ll wire the sliders + divisor exactly like the prototype.
      </div>
    </div>
  );
}
